# Countdown Timer Project

## Description
This project is a countdown timer built using HTML, CSS, and JavaScript. Users can set a future date and time, and the timer will count down in real-time.

## Features
- Set any future date and time
- Real-time countdown updates
- Message displayed when countdown reaches zero

## Technologies Used
- HTML
- CSS
- JavaScript

## How to Run
1. Open `index.html` in a web browser.
2. Set the desired future date and time.
3. Click "Start" to begin the countdown.
